-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 17, 2023 at 03:54 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbpegawai_kampusmerdeka`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `inputJabatan` (`nama` VARCHAR(45))   BEGIN
    INSERT INTO jabatan(nama) VALUES (nama);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `inputPegawai` (`nip` CHAR(3), `nama` VARCHAR(45), `jabatan_id` INT, `divisi_id` INT, `gender` CHAR(1), `tmp_lahir` VARCHAR(45), `tgl_lahir` DATE, `alamat` TEXT)   BEGIN
    INSERT INTO pegawai(nip,nama,jabatan_id,divisi_id,gender,tmp_lahir,tgl_lahir,alamat) VALUES
    (nip,nama,jabatan_id,divisi_id,gender,tmp_lahir,tgl_lahir,alamat);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `jumlah` (`a1` INT, `a2` INT, `total` INT)   BEGIN
	SET total = a1 + a2;
	SELECT @total;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `showJabatan` ()   BEGIN
    SELECT * FROM jabatan;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `totalGaji` (IN `gapok` DOUBLE, IN `tunjab` DOUBLE, OUT `total` DOUBLE)   BEGIN
	SET total = gapok + tunjab;
	SELECT @total;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `angkatan`
--

CREATE TABLE `angkatan` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `angkatan`
--

INSERT INTO `angkatan` (`id`, `nama`) VALUES
(1, '2017'),
(2, '2018'),
(3, '2019'),
(4, '2020'),
(5, '2021'),
(6, '2022'),
(7, '2023');

-- --------------------------------------------------------

--
-- Table structure for table `divisi`
--

CREATE TABLE `divisi` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `divisi`
--

INSERT INTO `divisi` (`id`, `nama`) VALUES
(21, 'ADMINISTRASI BISNIS '),
(16, 'ADMINISTRASI PUBLIK'),
(23, 'AGRIBISNIS '),
(22, 'AGROEKOTEKNOLOGI'),
(24, 'AKUAKULTUR'),
(27, 'AKUNTANSI'),
(18, 'ANTROPOLOGI'),
(7, 'ARSITEKTUR'),
(28, 'EKONOMI PEMBANGUNAN'),
(29, 'EKONOMI SYARIAH'),
(31, 'HUKUM'),
(25, 'ILMU KELAUTAN '),
(19, 'ILMU KOMUNIKASI'),
(17, 'ILMU POLITIK '),
(32, 'KEDOKTERAN '),
(30, 'KESEKRETARIATAN'),
(26, 'MANAJEMEN'),
(14, 'PENDIDIKAN BAHASA INDONESIA '),
(12, 'PENDIDIKAN FISIKA'),
(13, 'PENDIDIKAN KIMIA'),
(11, 'PENDIDIKAN MATEMATIKA'),
(15, 'PENDIDIKAN VOKASIONAL TEKNIK MESIN'),
(33, 'PSIKOLOGI'),
(10, 'SISTEM INFORMASI'),
(20, 'SOSIOLOGI'),
(6, 'TEKNIK ELEKTRO'),
(4, 'TEKNIK INDUSTRI'),
(1, 'TEKNIK INFORMATIKA'),
(5, 'TEKNIK KIMIA'),
(9, 'TEKNIK LOGISTIK'),
(8, 'TEKNIK MATERIAL'),
(3, 'TEKNIK MESIN'),
(2, 'TEKNIK SIPIL');

-- --------------------------------------------------------

--
-- Table structure for table `jabatan`
--

CREATE TABLE `jabatan` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jabatan`
--

INSERT INTO `jabatan` (`id`, `nama`) VALUES
(1, 'Semester 1'),
(2, 'Semester 2'),
(3, 'Semester 3'),
(4, 'Semester 4'),
(5, 'Semester 5'),
(6, 'Semester 6'),
(7, 'Semester 7'),
(8, 'Semester 8');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `id` int(11) NOT NULL,
  `fullname` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(40) NOT NULL,
  `role` enum('admin','manager','staff') NOT NULL,
  `foto` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`id`, `fullname`, `email`, `username`, `password`, `role`, `foto`) VALUES
(1, 'Manda', 'manda@gmail.com', 'admin', '0eb4e14e3a0af58fa4769fdad43ec79f52abfcdb', 'admin', 'manda.jpg'),
(2, 'Deden Hamdani', 'deden@gmail.com', 'deden', '6fe4540eb314dfd9a1e56cf50109e1786e4b308c', 'manager', NULL),
(3, 'Siti Aminah', 'siti@gmail.com', 'siti', '253667adfe329e2f57e4abb839c29fc1403cc988', 'staff', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pegawai`
--

CREATE TABLE `pegawai` (
  `id` int(11) NOT NULL,
  `nip` char(3) NOT NULL,
  `nama` varchar(45) NOT NULL,
  `jabatan_id` int(11) NOT NULL,
  `divisi_id` int(11) NOT NULL,
  `gender` enum('L','P') NOT NULL,
  `tmp_lahir` varchar(45) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `alamat` text DEFAULT NULL,
  `foto` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pegawai`
--

INSERT INTO `pegawai` (`id`, `nip`, `nama`, `jabatan_id`, `divisi_id`, `gender`, `tmp_lahir`, `tgl_lahir`, `alamat`, `foto`) VALUES
(1, '111', 'Budi Harahap', 2, 3, 'L', 'Medan', '1985-05-01', 'Cibinong Jawa Barat', 'budi.jpg'),
(2, '112', 'Siti Aminah', 2, 2, 'P', 'Bandung', '1988-08-01', 'Jatinegara', 'siti.jpg'),
(3, '113', 'Deden Hamdani', 3, 3, 'L', 'Banyuwangi', '1986-11-12', 'Kali Deres Jakarta Barat', 'deden.jpg'),
(4, '114', 'Manda Agustriya', 5, 1, 'P', 'Ranto peureulak', '2002-08-11', 'Aceh timur', 'manda.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `angkatan`
--
ALTER TABLE `angkatan`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nama_UNIQUE` (`nama`);

--
-- Indexes for table `divisi`
--
ALTER TABLE `divisi`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nama_UNIQUE` (`nama`);

--
-- Indexes for table `jabatan`
--
ALTER TABLE `jabatan`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nama_UNIQUE` (`nama`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nip_UNIQUE` (`nip`),
  ADD KEY `fk_pegawai_divisi` (`divisi_id`),
  ADD KEY `fk_pegawai_jabatan1` (`jabatan_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `divisi`
--
ALTER TABLE `divisi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `jabatan`
--
ALTER TABLE `jabatan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pegawai`
--
ALTER TABLE `pegawai`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `pegawai`
--
ALTER TABLE `pegawai`
  ADD CONSTRAINT `fk_pegawai_divisi` FOREIGN KEY (`divisi_id`) REFERENCES `divisi` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_pegawai_jabatan1` FOREIGN KEY (`jabatan_id`) REFERENCES `jabatan` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
